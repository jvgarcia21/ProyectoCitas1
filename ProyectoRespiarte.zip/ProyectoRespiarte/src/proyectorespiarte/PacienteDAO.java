/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectorespiarte;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Diego Hernandez
 */
public class PacienteDAO {
    public void insertarPaciente(Paciente paciente) {
        String sqlPersona = "INSERT INTO Persona (nombre, email, contrasena) VALUES (?, ?, ?)";
        String sqlPaciente = "INSERT INTO Paciente (id, historia, visitasPrevias) VALUES (?, ?, ?)";

        try (Connection conn = DataBaseConnection.getConnection();
             PreparedStatement stmtPersona = conn.prepareStatement(sqlPersona, PreparedStatement.RETURN_GENERATED_KEYS);
             PreparedStatement stmtPaciente = conn.prepareStatement(sqlPaciente)) {

            // Insertar datos en Persona
            stmtPersona.setString(1, paciente.getNombre());
            stmtPersona.setString(2, paciente.getEmail());
            stmtPersona.setString(3, paciente.getContrasena());
            stmtPersona.executeUpdate();

            // Obtener el ID generado
            ResultSet rs = stmtPersona.getGeneratedKeys();
            if (rs.next()) {
                int idPersona = rs.getInt(1);

                // Insertar datos en Paciente
                stmtPaciente.setInt(1, idPersona);
                stmtPaciente.setString(2, String.join(", ", paciente.getHistoria()));
                stmtPaciente.setString(3, String.join(", ", paciente.getVisitasPrevias()));
                stmtPaciente.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Paciente> obtenerPacientes() {
        List<Paciente> pacientes = new ArrayList<>();
        String sql = "SELECT p.id, p.nombre, p.email, p.contrasena, pa.historia, pa.visitasPrevias FROM Persona p JOIN Paciente pa ON p.id = pa.id";

        try (Connection conn = DataBaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Paciente paciente = new Paciente(
                        rs.getString("nombre"),
                        rs.getString("email"),
                        rs.getString("contrasena"),
                        List.of(rs.getString("historia").split(", ")),
                        List.of(rs.getString("visitasPrevias").split(", "))
                );
                pacientes.add(paciente);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return pacientes;
    }
}
