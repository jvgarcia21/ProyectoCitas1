/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectorespiarte;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
/**
 *
 * @author Diego Hernandez
 */
public class PersonaDAO {
    public void insertarPersona(Persona persona) {
        String sql = "INSERT INTO Persona (nombre, email, contrasena) VALUES (?, ?, ?)";

        try (Connection conn = DataBaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, persona.getNombre());
            stmt.setString(2, persona.getEmail());
            stmt.setString(3, persona.getContrasena());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    

    }}
