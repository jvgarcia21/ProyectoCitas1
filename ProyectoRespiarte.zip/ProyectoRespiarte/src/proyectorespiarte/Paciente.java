/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectorespiarte;

/**
 *
 * @author Diego Hernandez
 */
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public class Paciente extends Persona{
    protected List<String> historia;
    protected List<String> visitasPrevias;
    
    public Paciente(String nombre, String email, String contrasena, List<String>historia, List<String>visitasPrevias){
    super(nombre, email, contrasena);
        this.setHistoria(historia);
        this.setVisitasPrevias(visitasPrevias);
    }

    // Métodos para gestionar la historia clínica
    public void agregarHistoria(String entrada) {
        if (validarEntrada(entrada)) {
            historia.add(entrada);
        } else {
            System.out.println("Entrada de historia inválida.");
        }
    }

    public List<String> getHistoria() {
        return historia;
    }

    public void setHistoria(List<String> historia) {
        if (historia != null) {
            this.historia = historia;
        } else {
            this.historia = new ArrayList<>();
        }
    }

    // Métodos para gestionar visitas previas
    public void agregarVisita(String visita) {
        if (validarEntrada(visita)) {
            visitasPrevias.add(visita);
        } else {
            System.out.println("Entrada de visita inválida.");
        }
    }

    public List<String> getVisitasPrevias() {
        return visitasPrevias;
    }

    public void setVisitasPrevias(List<String> visitasPrevias) {
        
        if (visitasPrevias != null) {
            this.visitasPrevias = visitasPrevias;
        } else {
            this.visitasPrevias = new ArrayList<>();
        }
    }

    // Metodo de validacion para entradas de historia y visitas
    private boolean validarEntrada(String entrada) {
        try {
            
            if (entrada != null && !entrada.trim().isEmpty()) {
                return true;
            } else {
                throw new IllegalArgumentException("Entrada no puede estar vacía.");
            }
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
            return false;
        }
    }       
}