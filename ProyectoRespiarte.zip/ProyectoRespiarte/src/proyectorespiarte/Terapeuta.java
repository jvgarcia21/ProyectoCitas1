/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectorespiarte;

/**
 *
 * @author Diego Hernandez
 */
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class Terapeuta extends Persona {
    protected List<String> infoTerapeuta;

    // Constructor
    public Terapeuta(String nombre, String email, String contrasena, List<String> infoTerapeuta) {
        super(nombre, email, contrasena);
        this.setInfoTerapeuta(infoTerapeuta);
    }

    // Métodos para gestionar la información del terapeuta
    public void agregarInfo(String info) {
        if (validarEntrada(info)) {
            infoTerapeuta.add(info);
        } else {
            System.out.println("Información de terapeuta inválida.");
        }
    }

    public List<String> getInfoTerapeuta() {
        return infoTerapeuta;
    }

    public void setInfoTerapeuta(List<String> infoTerapeuta) {
        if (infoTerapeuta != null) {
            this.infoTerapeuta = infoTerapeuta;
        } else {
            this.infoTerapeuta = new ArrayList<>();
        }
    }

    // Método de validación para entradas de información
    private boolean validarEntrada(String entrada) {
        try {
            // Validación básica: no nulo y no vacío
            if (entrada != null && !entrada.trim().isEmpty()) {
                return true;
            } else {
                throw new IllegalArgumentException("La entrada no puede estar vacía.");
            }
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
            return false;
        }
    }

}
