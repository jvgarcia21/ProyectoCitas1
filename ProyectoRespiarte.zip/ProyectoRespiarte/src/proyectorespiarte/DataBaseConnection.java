/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectorespiarte;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
/**
 *
 * @author Diego Hernandez
 */
public class DataBaseConnection {
    protected static final String URL = "jdbc:mysql://localhost:3306/LocalInstanceMySQL91";
    protected static final String USER = "root";
    protected static final String PASSWORD = "proyectopoo1234";

    public static Connection getConnection() {
        try {
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    
}
}
