/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectorespiarte;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
/**
 *
 * @author Diego Hernandez
 */
public class Persona {
    protected String nombre;
    protected String email;
    protected String contrasena;

    // Constructor
    public Persona(String nombre, String email, String contrasena) {
        this.setNombre(nombre);
        this.setEmail(email);
        this.setContrasena(contrasena);
    }

    // Getters y Setters con Validación
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        try {
            // Expresión regular para validar nombres (solo letras y espacios)
            String regex = "^[a-zA-Z\\s]+$";
            Pattern pattern = Pattern.compile(regex);
            Matcher matcher = pattern.matcher(nombre);

            if (matcher.matches()) {
                this.nombre = nombre;
            } else {
                throw new IllegalArgumentException("Nombre inválido. Solo se permiten letras y espacios.");
            }
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        }
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        try {
            // Expresión regular para validar email
            String regex = "[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}";
            Pattern pattern = Pattern.compile(regex);
            Matcher matcher = pattern.matcher(email);

            if (matcher.matches()) {
                this.email = email;
            } else {
                throw new IllegalArgumentException("Email inválido.");
            }
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        }
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        try {
            // Validación básica de la contraseña
            if (contrasena != null && contrasena.length() >= 6) {
                this.contrasena = contrasena;
            } else {
                throw new IllegalArgumentException("La contraseña debe tener al menos 6 caracteres.");
            }
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        }
    }
}

    
    
    
    
    
    
    

