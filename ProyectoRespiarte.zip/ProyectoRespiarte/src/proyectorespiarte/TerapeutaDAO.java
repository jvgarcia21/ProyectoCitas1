/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectorespiarte;

/**
 *
 * @author Diego Hernandez
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TerapeutaDAO {
    public void insertarTerapeuta(Terapeuta terapeuta) {
        String sqlPersona = "INSERT INTO Persona (nombre, email, contrasena) VALUES (?, ?, ?)";
        String sqlTerapeuta = "INSERT INTO Terapeuta (id, infoTerapeuta) VALUES (?, ?)";

        try (Connection conn = DataBaseConnection.getConnection();
             PreparedStatement stmtPersona = conn.prepareStatement(sqlPersona, PreparedStatement.RETURN_GENERATED_KEYS);
             PreparedStatement stmtTerapeuta = conn.prepareStatement(sqlTerapeuta)) {

            // Insertar datos en Persona
            stmtPersona.setString(1, terapeuta.getNombre());
            stmtPersona.setString(2, terapeuta.getEmail());
            stmtPersona.setString(3, terapeuta.getContrasena());
            stmtPersona.executeUpdate();

            // Obtener el ID generado
            ResultSet rs = stmtPersona.getGeneratedKeys();
            if (rs.next()) {
                int idPersona = rs.getInt(1);

                // Insertar datos en Terapeuta
                stmtTerapeuta.setInt(1, idPersona);
                stmtTerapeuta.setString(2, String.join(", ", terapeuta.getInfoTerapeuta()));
                stmtTerapeuta.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Terapeuta> obtenerTerapeutas() {
        List<Terapeuta> terapeutas = new ArrayList<>();
        String sql = "SELECT p.id, p.nombre, p.email, p.contrasena, t.infoTerapeuta FROM Persona p JOIN Terapeuta t ON p.id = t.id";

        try (Connection conn = DataBaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Terapeuta terapeuta = new Terapeuta(
                        rs.getString("nombre"),
                        rs.getString("email"),
                        rs.getString("contrasena"),
                        List.of(rs.getString("infoTerapeuta").split(", "))
                );
                terapeutas.add(terapeuta);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return terapeutas;
    }
}
